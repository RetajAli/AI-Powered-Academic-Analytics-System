import 'package:application_1/auth/login.dart';
import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:google_fonts/google_fonts.dart';
import '../theme/app_colors.dart';


class DeanDashboard extends StatefulWidget {
  final String deanname;
  const DeanDashboard({super.key, required this.deanname});

  @override
  State<DeanDashboard> createState() => _DeanDashboardState();
}

class _DeanDashboardState extends State<DeanDashboard> {
  int _currentIndex = 0;

  late final List<Widget> _screens;

  @override
  void initState() {
    super.initState();
    _screens = [
      DeanOverviewTab(deanName: widget.deanname),
      const DeanDepartmentsTab(),
      const DeanInstructorsTab(),
      const DeanReportsTab(),
      const DeanAlertsTab(),
    ];
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bgDark,
      body: IndexedStack(index: _currentIndex, children: _screens),
      bottomNavigationBar: _buildBottomNav(),
    );
  }

  Widget _buildBottomNav() {
    const items = [
      (Icons.dashboard_customize_rounded, 'Overview'),
      (Icons.account_balance_rounded, 'Departments'),
      (Icons.people_alt_rounded, 'Instructors'),
      (Icons.analytics_rounded, 'Reports'),
      (Icons.notifications_active_rounded, 'Alerts'),
    ];

    return Container(
      decoration: BoxDecoration(
        color: AppColors.bgCard,
        border: Border(top: BorderSide(color: AppColors.border)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.4),
            blurRadius: 20,
            offset: const Offset(0, -5),
          ),
        ],
      ),
      child: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 8),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: List.generate(items.length, (i) {
              final isActive = _currentIndex == i;
              // Dean uses gold/amber accent
              const activeColor = Color(0xFFF59E0B);
              return GestureDetector(
                onTap: () => setState(() => _currentIndex = i),
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 250),
                  padding:
                  const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                  decoration: BoxDecoration(
                    color: isActive
                        ? activeColor.withOpacity(0.15)
                        : Colors.transparent,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(items[i].$1,
                          size: 22,
                          color: isActive ? activeColor : AppColors.textSecondary),
                      const SizedBox(height: 3),
                      Text(items[i].$2,
                          style: GoogleFonts.inter(
                              fontSize: 10,
                              fontWeight: isActive
                                  ? FontWeight.w600
                                  : FontWeight.w400,
                              color: isActive
                                  ? activeColor
                                  : AppColors.textSecondary)),
                    ],
                  ),
                ),
              );
            }),
          ),
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────
// Shared header widget
// ─────────────────────────────────────────────────────────
class _DeanHeader extends StatelessWidget {
  final String title;
  final String subtitle;
  final bool showLogout;

  const _DeanHeader({
    required this.title,
    required this.subtitle,
    this.showLogout = false,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.fromLTRB(16, 16, 16, 8),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Color(0xFF1a1500), Color(0xFF1a1200)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: const Color(0xFFF59E0B).withOpacity(0.35)),
      ),
      child: Row(
        children: [
          // Dean badge
          Container(
            width: 52,
            height: 52,
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [Color(0xFFF59E0B), Color(0xFFD97706)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(14),
              boxShadow: [
                BoxShadow(
                  color: const Color(0xFFF59E0B).withOpacity(0.4),
                  blurRadius: 12,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: const Icon(Icons.account_balance_rounded,
                color: Colors.white, size: 26),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title,
                    style: GoogleFonts.spaceGrotesk(
                        fontSize: 18,
                        fontWeight: FontWeight.w700,
                        color: Colors.white)),
                Text(subtitle,
                    style: GoogleFonts.inter(
                        fontSize: 12, color: AppColors.textSecondary)),
              ],
            ),
          ),
          if (showLogout)
            GestureDetector(
              onTap: () => Navigator.pushReplacement(
                context,
                MaterialPageRoute(builder: (_) => const LoginScreen()),
              ),
              child: Container(
                padding:
                const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
                decoration: BoxDecoration(
                  color: AppColors.red.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: AppColors.red.withOpacity(0.4)),
                ),
                child: Row(
                  children: [
                    const Icon(Icons.logout_rounded,
                        color: AppColors.red, size: 15),
                    const SizedBox(width: 4),
                    Text('Logout',
                        style: GoogleFonts.inter(
                            fontSize: 11,
                            color: AppColors.red,
                            fontWeight: FontWeight.w600)),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────
// TAB 1: Dean Overview
// ─────────────────────────────────────────────────────────
class DeanOverviewTab extends StatelessWidget {
  final String deanName;
  const DeanOverviewTab({super.key, required this.deanName});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(gradient: AppGradients.background),
      child: SafeArea(
        child: CustomScrollView(
          slivers: [
            SliverToBoxAdapter(
              child: _DeanHeader(
                title: 'Welcome, Dean',
                subtitle:
                'College-wide performance, enrollment & faculty overview',
                showLogout: true,
              ),
            ),
            SliverToBoxAdapter(child: _buildKpiRow()),
            SliverToBoxAdapter(child: _buildEnrollmentChart()),
            SliverToBoxAdapter(child: _buildGpaDistribution()),
            SliverToBoxAdapter(child: _buildQuickAlerts()),
            const SliverToBoxAdapter(child: SizedBox(height: 24)),
          ],
        ),
      ),
    );
  }

  Widget _buildKpiRow() {
    final kpis = [
      ('1,240', 'Total Students', const Color(0xFF06B6D4), Icons.people_alt_rounded),
      ('48', 'Instructors', const Color(0xFF10B981), Icons.school_rounded),
      ('6', 'Departments', const Color(0xFFF59E0B), Icons.account_balance_rounded),
      ('3.41', 'College GPA', const Color(0xFF8B5CF6), Icons.grade_rounded),
    ];

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: GridView.count(
        crossAxisCount: 2,
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        mainAxisSpacing: 10,
        crossAxisSpacing: 10,
        childAspectRatio: 1.7,
        children: kpis.map((k) {
          return Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: k.$3.withOpacity(0.1),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: k.$3.withOpacity(0.3)),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(k.$1,
                        style: GoogleFonts.spaceGrotesk(
                            fontSize: 24,
                            fontWeight: FontWeight.w800,
                            color: k.$3)),
                    Icon(k.$4, color: k.$3.withOpacity(0.5), size: 26),
                  ],
                ),
                Text(k.$2,
                    style: GoogleFonts.inter(
                        fontSize: 11, color: AppColors.textSecondary)),
              ],
            ),
          );
        }).toList(),
      ),
    );
  }

  Widget _buildEnrollmentChart() {
    return Padding(
      padding: const EdgeInsets.all(16),
      child: Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: AppColors.bgCard,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: AppColors.border),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Icon(Icons.trending_up_rounded,
                    color: Color(0xFFF59E0B), size: 20),
                const SizedBox(width: 8),
                Text('Enrollment Trend (Last 6 Months)',
                    style: GoogleFonts.spaceGrotesk(
                        fontSize: 15,
                        fontWeight: FontWeight.w700,
                        color: AppColors.textPrimary)),
              ],
            ),
            const SizedBox(height: 20),
            SizedBox(
              height: 190,
              child: LineChart(LineChartData(
                gridData: FlGridData(
                  drawVerticalLine: false,
                  getDrawingHorizontalLine: (_) =>
                      FlLine(color: AppColors.border, strokeWidth: 1),
                ),
                titlesData: FlTitlesData(
                  bottomTitles: AxisTitles(
                    sideTitles: SideTitles(
                      showTitles: true,
                      getTitlesWidget: (val, _) {
                        const months = [
                          'Nov', 'Dec', 'Jan', 'Feb', 'Mar', 'Apr'
                        ];
                        final i = val.toInt();
                        if (i >= 0 && i < months.length) {
                          return Padding(
                            padding: const EdgeInsets.only(top: 6),
                            child: Text(months[i],
                                style: GoogleFonts.inter(
                                    fontSize: 11,
                                    color: AppColors.textSecondary)),
                          );
                        }
                        return const Text('');
                      },
                    ),
                  ),
                  leftTitles: AxisTitles(
                    sideTitles: SideTitles(
                      showTitles: true,
                      reservedSize: 38,
                      getTitlesWidget: (val, _) => Text(
                        val.toInt().toString(),
                        style: GoogleFonts.inter(
                            fontSize: 10, color: AppColors.textSecondary),
                      ),
                    ),
                  ),
                  topTitles: const AxisTitles(
                      sideTitles: SideTitles(showTitles: false)),
                  rightTitles: const AxisTitles(
                      sideTitles: SideTitles(showTitles: false)),
                ),
                borderData: FlBorderData(show: false),
                minY: 1000,
                maxY: 1400,
                lineBarsData: [
                  LineChartBarData(
                    spots: const [
                      FlSpot(0, 1080),
                      FlSpot(1, 1120),
                      FlSpot(2, 1150),
                      FlSpot(3, 1190),
                      FlSpot(4, 1220),
                      FlSpot(5, 1240),
                    ],
                    isCurved: true,
                    color: const Color(0xFFF59E0B),
                    barWidth: 3,
                    dotData: FlDotData(
                      getDotPainter: (_, __, ___, ____) => FlDotCirclePainter(
                        radius: 4,
                        color: const Color(0xFFF59E0B),
                        strokeWidth: 2,
                        strokeColor: AppColors.bgDark,
                      ),
                    ),
                    belowBarData: BarAreaData(
                      show: true,
                      color: const Color(0xFFF59E0B).withOpacity(0.08),
                    ),
                  ),
                ],
              )),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildGpaDistribution() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: AppColors.bgCard,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: AppColors.border),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Icon(Icons.bar_chart_rounded,
                    color: Color(0xFF8B5CF6), size: 20),
                const SizedBox(width: 8),
                Text('GPA Distribution by Department',
                    style: GoogleFonts.spaceGrotesk(
                        fontSize: 15,
                        fontWeight: FontWeight.w700,
                        color: AppColors.textPrimary)),
              ],
            ),
            const SizedBox(height: 20),
            SizedBox(
              height: 200,
              child: BarChart(BarChartData(
                alignment: BarChartAlignment.spaceAround,
                maxY: 4,
                barTouchData: BarTouchData(enabled: true),
                titlesData: FlTitlesData(
                  bottomTitles: AxisTitles(
                    sideTitles: SideTitles(
                      showTitles: true,
                      getTitlesWidget: (val, _) {
                        const depts = [
                          'CS', 'Math', 'Phys', 'Chem', 'Bio', 'Eng'
                        ];
                        final i = val.toInt();
                        if (i >= 0 && i < depts.length) {
                          return Padding(
                            padding: const EdgeInsets.only(top: 6),
                            child: Text(depts[i],
                                style: GoogleFonts.inter(
                                    fontSize: 10,
                                    color: AppColors.textSecondary)),
                          );
                        }
                        return const Text('');
                      },
                    ),
                  ),
                  leftTitles: AxisTitles(
                    sideTitles: SideTitles(
                      showTitles: true,
                      reservedSize: 30,
                      getTitlesWidget: (val, _) => Text(
                        val.toStringAsFixed(1),
                        style: GoogleFonts.inter(
                            fontSize: 10, color: AppColors.textSecondary),
                      ),
                    ),
                  ),
                  topTitles: const AxisTitles(
                      sideTitles: SideTitles(showTitles: false)),
                  rightTitles: const AxisTitles(
                      sideTitles: SideTitles(showTitles: false)),
                ),
                gridData: FlGridData(
                  drawVerticalLine: false,
                  getDrawingHorizontalLine: (_) =>
                      FlLine(color: AppColors.border, strokeWidth: 1),
                ),
                borderData: FlBorderData(show: false),
                barGroups: [
                  _deptBar(0, 3.52, const Color(0xFF6C63FF)),
                  _deptBar(1, 3.41, const Color(0xFF06B6D4)),
                  _deptBar(2, 3.28, const Color(0xFF10B981)),
                  _deptBar(3, 3.15, const Color(0xFFF59E0B)),
                  _deptBar(4, 3.38, const Color(0xFFEF4444)),
                  _deptBar(5, 3.60, const Color(0xFF8B5CF6)),
                ],
              )),
            ),
          ],
        ),
      ),
    );
  }

  BarChartGroupData _deptBar(int x, double y, Color color) {
    return BarChartGroupData(
      x: x,
      barRods: [
        BarChartRodData(
          toY: y,
          color: color,
          width: 28,
          borderRadius: const BorderRadius.vertical(top: Radius.circular(6)),
        ),
      ],
    );
  }

  Widget _buildQuickAlerts() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
      child: Container(
        padding: const EdgeInsets.all(18),
        decoration: BoxDecoration(
          color: AppColors.bgCard,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: AppColors.border),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Critical Alerts',
                style: GoogleFonts.spaceGrotesk(
                    fontSize: 15,
                    fontWeight: FontWeight.w700,
                    color: AppColors.textPrimary)),
            const SizedBox(height: 14),
            _alertRow(
                Icons.warning_amber_rounded,
                '23 students below passing threshold',
                'Requires immediate intervention',
                AppColors.red),
            _alertRow(
                Icons.trending_down_rounded,
                'Chemistry dept. avg dropped 4.2%',
                'Compared to last semester',
                AppColors.accent),
            _alertRow(
                Icons.event_busy_rounded,
                '8 instructors with attendance issues',
                'Below 80% session rate',
                AppColors.purple),
          ],
        ),
      ),
    );
  }

  Widget _alertRow(
      IconData icon, String title, String sub, Color color) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: color.withOpacity(0.12),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(icon, color: color, size: 18),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title,
                    style: GoogleFonts.inter(
                        fontSize: 13,
                        fontWeight: FontWeight.w600,
                        color: AppColors.textPrimary)),
                Text(sub,
                    style: GoogleFonts.inter(
                        fontSize: 11, color: AppColors.textSecondary)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────
// TAB 2: Departments
// ─────────────────────────────────────────────────────────
class DeanDepartmentsTab extends StatelessWidget {
  const DeanDepartmentsTab({super.key});

  @override
  Widget build(BuildContext context) {
    final depts = [
      _DeptData('Computer Science', 280, 3.52, 87, 12, const Color(0xFF6C63FF),
          Icons.computer_rounded),
      _DeptData('Mathematics', 195, 3.41, 83, 8, const Color(0xFF06B6D4),
          Icons.calculate_rounded),
      _DeptData('Physics', 160, 3.28, 80, 7, const Color(0xFF10B981),
          Icons.science_rounded),
      _DeptData('Chemistry', 175, 3.15, 76, 9, const Color(0xFFF59E0B),
          Icons.biotech_rounded),
      _DeptData('Biology', 210, 3.38, 85, 8, const Color(0xFFEF4444),
          Icons.eco_rounded),
      _DeptData('Engineering', 220, 3.60, 89, 4, const Color(0xFF8B5CF6),
          Icons.engineering_rounded),
    ];

    return Container(
      decoration: const BoxDecoration(gradient: AppGradients.background),
      child: SafeArea(
        child: Column(
          children: [
            const _DeanHeader(
              title: 'Departments',
              subtitle: 'College-wide departmental performance',
            ),
            Expanded(
              child: ListView.builder(
                padding: const EdgeInsets.all(16),
                itemCount: depts.length,
                itemBuilder: (_, i) => _DeptCard(data: depts[i]),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _DeptData {
  final String name;
  final int students;
  final double gpa;
  final int attendance;
  final int instructors;
  final Color color;
  final IconData icon;

  const _DeptData(this.name, this.students, this.gpa, this.attendance,
      this.instructors, this.color, this.icon);
}

class _DeptCard extends StatelessWidget {
  final _DeptData data;
  const _DeptCard({required this.data});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: AppColors.bgCard,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        children: [
          Row(
            children: [
              Container(
                width: 48,
                height: 48,
                decoration: BoxDecoration(
                  color: data.color.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(13),
                ),
                child: Icon(data.icon, color: data.color, size: 24),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(data.name,
                        style: GoogleFonts.spaceGrotesk(
                            fontSize: 15,
                            fontWeight: FontWeight.w700,
                            color: AppColors.textPrimary)),
                    Text('${data.instructors} instructors · ${data.students} students',
                        style: GoogleFonts.inter(
                            fontSize: 12, color: AppColors.textSecondary)),
                  ],
                ),
              ),
              Container(
                padding:
                const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                decoration: BoxDecoration(
                  color: data.color.withOpacity(0.12),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text('GPA ${data.gpa}',
                    style: GoogleFonts.spaceGrotesk(
                        fontSize: 13,
                        fontWeight: FontWeight.w700,
                        color: data.color)),
              ),
            ],
          ),
          const SizedBox(height: 14),
          Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text('Attendance',
                            style: GoogleFonts.inter(
                                fontSize: 11,
                                color: AppColors.textSecondary)),
                        Text('${data.attendance}%',
                            style: GoogleFonts.inter(
                                fontSize: 11,
                                fontWeight: FontWeight.w600,
                                color: AppColors.textPrimary)),
                      ],
                    ),
                    const SizedBox(height: 5),
                    LinearProgressIndicator(
                      value: data.attendance / 100,
                      backgroundColor: AppColors.border,
                      valueColor: AlwaysStoppedAnimation(data.color),
                      borderRadius: BorderRadius.circular(4),
                      minHeight: 6,
                    ),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────
// TAB 3: Instructors
// ─────────────────────────────────────────────────────────
class DeanInstructorsTab extends StatelessWidget {
  const DeanInstructorsTab({super.key});

  @override
  Widget build(BuildContext context) {
    final instructors = [
      _InstrData('Dr. Mohamed Fathy', 'Computer Science', 4.8, 92, 149,
          AppColors.green, 'Top Performer'),
      _InstrData('Dr. Sarah Ahmed', 'Mathematics', 4.5, 88, 120,
          AppColors.teal, 'Excellent'),
      _InstrData('Dr. Omar Hassan', 'Physics', 4.2, 85, 108,
          AppColors.primary, 'Good'),
      _InstrData('Dr. Nour Ali', 'Chemistry', 3.8, 76, 95,
          AppColors.accent, 'Average'),
      _InstrData('Dr. Layla Ibrahim', 'Biology', 4.6, 90, 135,
          AppColors.green, 'Excellent'),
      _InstrData('Dr. Khaled Mansour', 'Engineering', 3.5, 72, 88,
          AppColors.red, 'Needs Review'),
    ];

    return Container(
      decoration: const BoxDecoration(gradient: AppGradients.background),
      child: SafeArea(
        child: Column(
          children: [
            const _DeanHeader(
              title: 'Instructors',
              subtitle: 'Faculty performance & teaching metrics',
            ),
            Expanded(
              child: ListView.builder(
                padding: const EdgeInsets.all(16),
                itemCount: instructors.length,
                itemBuilder: (_, i) => _InstrCard(data: instructors[i]),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _InstrData {
  final String name;
  final String dept;
  final double rating;
  final int attendance;
  final int students;
  final Color color;
  final String badge;
  const _InstrData(this.name, this.dept, this.rating, this.attendance,
      this.students, this.color, this.badge);
}

class _InstrCard extends StatelessWidget {
  final _InstrData data;
  const _InstrCard({required this.data});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.bgCard,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.border),
      ),
      child: Row(
        children: [
          CircleAvatar(
            radius: 24,
            backgroundColor: data.color.withOpacity(0.15),
            child: Text(data.name.split(' ').last[0],
                style: GoogleFonts.spaceGrotesk(
                    fontSize: 18,
                    fontWeight: FontWeight.w800,
                    color: data.color)),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Expanded(
                      child: Text(data.name,
                          style: GoogleFonts.inter(
                              fontSize: 13,
                              fontWeight: FontWeight.w600,
                              color: AppColors.textPrimary)),
                    ),
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 8, vertical: 3),
                      decoration: BoxDecoration(
                        color: data.color.withOpacity(0.12),
                        borderRadius: BorderRadius.circular(6),
                      ),
                      child: Text(data.badge,
                          style: GoogleFonts.inter(
                              fontSize: 10,
                              fontWeight: FontWeight.w600,
                              color: data.color)),
                    ),
                  ],
                ),
                Text(data.dept,
                    style: GoogleFonts.inter(
                        fontSize: 11, color: AppColors.textSecondary)),
                const SizedBox(height: 6),
                Row(
                  children: [
                    const Icon(Icons.star_rounded,
                        size: 13, color: Color(0xFFF59E0B)),
                    const SizedBox(width: 3),
                    Text('${data.rating}',
                        style: GoogleFonts.inter(
                            fontSize: 11,
                            color: AppColors.textSecondary,
                            fontWeight: FontWeight.w600)),
                    const SizedBox(width: 12),
                    const Icon(Icons.people_rounded,
                        size: 13, color: AppColors.textSecondary),
                    const SizedBox(width: 3),
                    Text('${data.students} students',
                        style: GoogleFonts.inter(
                            fontSize: 11,
                            color: AppColors.textSecondary)),
                    const SizedBox(width: 12),
                    const Icon(Icons.calendar_today_rounded,
                        size: 12, color: AppColors.textSecondary),
                    const SizedBox(width: 3),
                    Text('${data.attendance}%',
                        style: GoogleFonts.inter(
                            fontSize: 11,
                            color: AppColors.textSecondary)),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────
// TAB 4: Reports
// ─────────────────────────────────────────────────────────
class DeanReportsTab extends StatelessWidget {
  const DeanReportsTab({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(gradient: AppGradients.background),
      child: SafeArea(
        child: Column(
          children: [
            const _DeanHeader(
              title: 'College Reports',
              subtitle: 'Semester & annual performance summaries',
            ),
            Expanded(
              child: ListView(
                padding: const EdgeInsets.all(16),
                children: [
                  _sectionTitle('Semester Summary'),
                  _reportTile(Icons.summarize_rounded,
                      'Spring 2025 – Academic Summary',
                      'Overall GPA: 3.41 · Pass Rate: 87.2%',
                      const Color(0xFF6C63FF)),
                  _reportTile(Icons.groups_rounded,
                      'Student Retention Report',
                      '96.3% retention · 47 at-risk students',
                      AppColors.teal),
                  _reportTile(Icons.attach_money_rounded,
                      'Scholarship & Aid Allocation',
                      '312 students receiving aid',
                      AppColors.green),
                  const SizedBox(height: 8),
                  _sectionTitle('Department Analytics'),
                  _reportTile(Icons.computer_rounded,
                      'CS Department – Semester Report',
                      'Top dept · GPA 3.52 · 280 students',
                      const Color(0xFF8B5CF6)),
                  _reportTile(Icons.biotech_rounded,
                      'Chemistry – Performance Decline',
                      'GPA dropped 0.18 vs. last semester',
                      AppColors.red),
                  const SizedBox(height: 8),
                  _sectionTitle('Faculty Reports'),
                  _reportTile(Icons.workspace_premium_rounded,
                      'Top-Rated Instructors – Spring 2025',
                      '6 instructors rated above 4.5',
                      AppColors.accent),
                  _reportTile(Icons.report_problem_rounded,
                      'Instructors Under Review',
                      '3 instructors flagged for low performance',
                      AppColors.red),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _sectionTitle(String title) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10, top: 4),
      child: Text(title,
          style: GoogleFonts.spaceGrotesk(
              fontSize: 14,
              fontWeight: FontWeight.w700,
              color: AppColors.textSecondary,
              letterSpacing: 0.5)),
    );
  }

  Widget _reportTile(
      IconData icon, String title, String sub, Color color) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.bgCard,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppColors.border),
      ),
      child: Row(
        children: [
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(
              color: color.withOpacity(0.12),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(icon, color: color, size: 22),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title,
                    style: GoogleFonts.inter(
                        fontSize: 13,
                        fontWeight: FontWeight.w600,
                        color: AppColors.textPrimary)),
                Text(sub,
                    style: GoogleFonts.inter(
                        fontSize: 11, color: AppColors.textSecondary)),
              ],
            ),
          ),
          const Icon(Icons.chevron_right_rounded,
              color: AppColors.textSecondary, size: 20),
        ],
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────
// TAB 5: Alerts
// ─────────────────────────────────────────────────────────
class DeanAlertsTab extends StatelessWidget {
  const DeanAlertsTab({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(gradient: AppGradients.background),
      child: SafeArea(
        child: Column(
          children: [
            const _DeanHeader(
              title: 'Alerts & Actions',
              subtitle: 'Items requiring dean attention',
            ),
            Expanded(
              child: ListView(
                padding: const EdgeInsets.all(16),
                children: [
                  _alertCard(
                    priority: 'CRITICAL',
                    priorityColor: AppColors.red,
                    icon: Icons.person_off_rounded,
                    title: '23 Students Below Passing Threshold',
                    body:
                    'These students have a GPA below 2.0 and are at risk of academic dismissal. Immediate advising recommended.',
                    time: 'Today, 09:15 AM',
                  ),
                  _alertCard(
                    priority: 'HIGH',
                    priorityColor: AppColors.accent,
                    icon: Icons.trending_down_rounded,
                    title: 'Chemistry Dept. GPA Decline',
                    body:
                    'Department average GPA dropped from 3.33 to 3.15 compared to the previous semester. Faculty review advised.',
                    time: 'Yesterday',
                  ),
                  _alertCard(
                    priority: 'HIGH',
                    priorityColor: AppColors.accent,
                    icon: Icons.event_busy_rounded,
                    title: '8 Instructors Below Session Threshold',
                    body:
                    'These instructors have conducted fewer than 80% of their scheduled sessions. HR review may be required.',
                    time: '2 days ago',
                  ),
                  _alertCard(
                    priority: 'MEDIUM',
                    priorityColor: AppColors.primary,
                    icon: Icons.school_rounded,
                    title: 'New Enrollment Applications',
                    body:
                    '47 new transfer applications pending dean approval for Spring 2026 intake.',
                    time: '3 days ago',
                  ),
                  _alertCard(
                    priority: 'LOW',
                    priorityColor: AppColors.green,
                    icon: Icons.workspace_premium_rounded,
                    title: 'Dean\'s List Nominations Ready',
                    body:
                    '89 students have been nominated for the Dean\'s List this semester. Approval pending.',
                    time: '1 week ago',
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _alertCard({
    required String priority,
    required Color priorityColor,
    required IconData icon,
    required String title,
    required String body,
    required String time,
  }) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        color: AppColors.bgCard,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: priorityColor.withOpacity(0.3)),
      ),
      child: Column(
        children: [
          // Priority banner
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
            decoration: BoxDecoration(
              color: priorityColor.withOpacity(0.1),
              borderRadius:
              const BorderRadius.vertical(top: Radius.circular(15)),
            ),
            child: Row(
              children: [
                Container(
                  width: 8,
                  height: 8,
                  decoration: BoxDecoration(
                    color: priorityColor,
                    borderRadius: BorderRadius.circular(4),
                  ),
                ),
                const SizedBox(width: 8),
                Text(priority,
                    style: GoogleFonts.spaceGrotesk(
                        fontSize: 11,
                        fontWeight: FontWeight.w700,
                        color: priorityColor,
                        letterSpacing: 1)),
                const Spacer(),
                Text(time,
                    style: GoogleFonts.inter(
                        fontSize: 11, color: AppColors.textSecondary)),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(14),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: priorityColor.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Icon(icon, color: priorityColor, size: 20),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(title,
                          style: GoogleFonts.inter(
                              fontSize: 13,
                              fontWeight: FontWeight.w700,
                              color: AppColors.textPrimary)),
                      const SizedBox(height: 4),
                      Text(body,
                          style: GoogleFonts.inter(
                              fontSize: 12,
                              color: AppColors.textSecondary,
                              height: 1.5)),
                      const SizedBox(height: 10),
                      Row(
                        children: [
                          _actionBtn('Review', priorityColor),
                          const SizedBox(width: 8),
                          _actionBtn('Dismiss', AppColors.textSecondary),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _actionBtn(String label, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
      decoration: BoxDecoration(
        color: color.withOpacity(0.12),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: color.withOpacity(0.3)),
      ),
      child: Text(label,
          style: GoogleFonts.inter(
              fontSize: 11, fontWeight: FontWeight.w600, color: color)),
    );
  }
}