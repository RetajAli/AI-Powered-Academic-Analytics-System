import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:google_fonts/google_fonts.dart';
import '../theme/app_colors.dart';
import '../auth/login.dart';

class StudentDashboard extends StatefulWidget {
  final String studentName;
  const StudentDashboard({super.key, required this.studentName});

  @override
  State<StudentDashboard> createState() => _StudentDashboardState();
}

class _StudentDashboardState extends State<StudentDashboard> {
  int _currentIndex = 0;

  late final List<Widget> _screens;

  @override
  void initState() {
    super.initState();
    _screens = [
      StudentHomeTab(studentName: widget.studentName),
      const StudentCoursesTab(),
      const StudentGradesTab(),
      const StudentProfileTab(),
    ];
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bgDark,
      body: IndexedStack(index: _currentIndex, children: _screens),
      bottomNavigationBar: _buildBottomNav(),
    );
  }

  Widget _buildBottomNav() {
    const items = [
      (Icons.home_rounded, 'Home'),
      (Icons.book_rounded, 'Courses'),
      (Icons.grade_rounded, 'Grades'),
      (Icons.person_rounded, 'Profile'),
    ];

    return Container(
      decoration: BoxDecoration(
        color: AppColors.bgCard,
        border: Border(top: BorderSide(color: AppColors.border)),
      ),
      child: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 8),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: List.generate(items.length, (i) {
              final isActive = _currentIndex == i;
              return GestureDetector(
                onTap: () => setState(() => _currentIndex = i),
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 250),
                  padding:
                      const EdgeInsets.symmetric(horizontal: 18, vertical: 8),
                  decoration: BoxDecoration(
                    color: isActive
                        ? AppColors.teal.withOpacity(0.15)
                        : Colors.transparent,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(items[i].$1,
                          size: 22,
                          color: isActive
                              ? AppColors.teal
                              : AppColors.textSecondary),
                      const SizedBox(height: 3),
                      Text(items[i].$2,
                          style: GoogleFonts.inter(
                              fontSize: 10,
                              fontWeight: isActive
                                  ? FontWeight.w600
                                  : FontWeight.w400,
                              color: isActive
                                  ? AppColors.teal
                                  : AppColors.textSecondary)),
                    ],
                  ),
                ),
              );
            }),
          ),
        ),
      ),
    );
  }
}

// ───────────────────────────────────────────────
// Student Home Tab
// ───────────────────────────────────────────────
class StudentHomeTab extends StatelessWidget {
  final String studentName;
  const StudentHomeTab({super.key, required this.studentName});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(gradient: AppGradients.background),
      child: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Header
              Row(
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('Hello, $studentName 👋',
                            style: GoogleFonts.spaceGrotesk(
                                fontSize: 22,
                                fontWeight: FontWeight.w700,
                                color: AppColors.textPrimary)),
                        Text('Keep up the great work!',
                            style: GoogleFonts.inter(
                                fontSize: 13,
                                color: AppColors.textSecondary)),
                      ],
                    ),
                  ),
                  GestureDetector(
                    onTap: () => Navigator.pushReplacement(
                      context,
                      MaterialPageRoute(
                          builder: (_) => const LoginScreen()),
                    ),
                    child: Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: AppColors.red.withOpacity(0.15),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: const Icon(Icons.logout_rounded,
                          color: AppColors.red, size: 20),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 20),
              // Stats row
              Row(
                children: [
                  _statCard('82.4', 'My GPA', AppGradients.statGreen),
                  const SizedBox(width: 10),
                  _statCard('89%', 'Attendance', AppGradients.statBlue),
                  const SizedBox(width: 10),
                  _statCard('76%', 'Activity', AppGradients.statPurple),
                ],
              ),
              const SizedBox(height: 20),
              Text('My Performance',
                  style: GoogleFonts.spaceGrotesk(
                      fontSize: 16,
                      fontWeight: FontWeight.w700,
                      color: AppColors.textPrimary)),
              const SizedBox(height: 12),
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: AppColors.bgCard,
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: AppColors.border),
                ),
                child: SizedBox(
                  height: 180,
                  child: RadarChart(
                    RadarChartData(
                      radarShape: RadarShape.polygon,
                      tickCount: 4,
                      ticksTextStyle: GoogleFonts.inter(
                          fontSize: 0, color: Colors.transparent),
                      radarBorderData:
                          const BorderSide(color: AppColors.border),
                      gridBorderData:
                          const BorderSide(color: AppColors.border, width: 1),
                      tickBorderData:
                          const BorderSide(color: AppColors.border),
                      getTitle: (index, angle) {
                        const titles = [
                          'Exams',
                          'Homework',
                          'Attendance',
                          'Activity',
                          'Quizzes'
                        ];
                        return RadarChartTitle(
                          text: titles[index],
                          angle: angle,
                        );
                      },
                      dataSets: [
                        RadarDataSet(
                          fillColor: AppColors.teal.withOpacity(0.2),
                          borderColor: AppColors.teal,
                          dataEntries: const [
                            RadarEntry(value: 82),
                            RadarEntry(value: 88),
                            RadarEntry(value: 89),
                            RadarEntry(value: 76),
                            RadarEntry(value: 91),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 20),
              Text('Upcoming Deadlines',
                  style: GoogleFonts.spaceGrotesk(
                      fontSize: 16,
                      fontWeight: FontWeight.w700,
                      color: AppColors.textPrimary)),
              const SizedBox(height: 12),
              _deadlineCard('Assignment 4', 'Advanced Statistics',
                  'Due in 2 days', AppColors.red),
              _deadlineCard('Midterm Project', 'Linear Algebra',
                  'Due in 5 days', AppColors.accent),
              _deadlineCard('Lab Report', 'Physics',
                  'Due in 1 week', AppColors.green),
            ],
          ),
        ),
      ),
    );
  }

  Widget _statCard(String value, String label, LinearGradient gradient) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          gradient: gradient,
          borderRadius: BorderRadius.circular(14),
        ),
        child: Column(
          children: [
            Text(value,
                style: GoogleFonts.spaceGrotesk(
                    fontSize: 20,
                    fontWeight: FontWeight.w800,
                    color: Colors.white)),
            Text(label,
                style: GoogleFonts.inter(
                    fontSize: 11, color: Colors.white.withOpacity(0.8))),
          ],
        ),
      ),
    );
  }

  Widget _deadlineCard(
      String title, String course, String due, Color color) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.bgCard,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppColors.border),
      ),
      child: Row(
        children: [
          Container(
            width: 4,
            height: 42,
            decoration: BoxDecoration(
              color: color,
              borderRadius: BorderRadius.circular(4),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title,
                    style: GoogleFonts.inter(
                        fontSize: 14,
                        fontWeight: FontWeight.w600,
                        color: AppColors.textPrimary)),
                Text(course,
                    style: GoogleFonts.inter(
                        fontSize: 12, color: AppColors.textSecondary)),
              ],
            ),
          ),
          Text(due,
              style: GoogleFonts.inter(fontSize: 12, color: color)),
        ],
      ),
    );
  }
}

// ───────────────────────────────────────────────
// Student Courses Tab
// ───────────────────────────────────────────────
class StudentCoursesTab extends StatelessWidget {
  const StudentCoursesTab({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(gradient: AppGradients.background),
      child: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('My Courses',
                  style: GoogleFonts.spaceGrotesk(
                      fontSize: 24,
                      fontWeight: FontWeight.w700,
                      color: AppColors.textPrimary)),
              const SizedBox(height: 16),
              Expanded(
                child: GridView.count(
                  crossAxisCount: 2,
                  crossAxisSpacing: 12,
                  mainAxisSpacing: 12,
                  children: [
                    _courseCard('Advanced\nStatistics', 'Dr. Ahmed',
                        AppColors.purple, Icons.bar_chart_rounded, 77),
                    _courseCard('Linear\nAlgebra', 'Dr. Sarah',
                        AppColors.teal, Icons.calculate_rounded, 82),
                    _courseCard('Calculus', 'Dr. Omar',
                        AppColors.green, Icons.functions_rounded, 71),
                    _courseCard('Physics', 'Dr. Nour',
                        AppColors.accent, Icons.science_rounded, 68),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _courseCard(String name, String instructor, Color color,
      IconData icon, int progress) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.bgCard,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(
              color: color.withOpacity(0.2),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(icon, color: color, size: 24),
          ),
          const Spacer(),
          Text(name,
              style: GoogleFonts.spaceGrotesk(
                  fontSize: 15,
                  fontWeight: FontWeight.w700,
                  color: AppColors.textPrimary)),
          Text(instructor,
              style: GoogleFonts.inter(
                  fontSize: 11, color: AppColors.textSecondary)),
          const SizedBox(height: 8),
          LinearProgressIndicator(
            value: progress / 100,
            backgroundColor: AppColors.border,
            valueColor: AlwaysStoppedAnimation(color),
            borderRadius: BorderRadius.circular(4),
          ),
          const SizedBox(height: 4),
          Text('$progress% complete',
              style: GoogleFonts.inter(fontSize: 10, color: color)),
        ],
      ),
    );
  }
}

// ───────────────────────────────────────────────
// Student Grades Tab
// ───────────────────────────────────────────────
class StudentGradesTab extends StatelessWidget {
  const StudentGradesTab({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(gradient: AppGradients.background),
      child: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('My Grades',
                  style: GoogleFonts.spaceGrotesk(
                      fontSize: 24,
                      fontWeight: FontWeight.w700,
                      color: AppColors.textPrimary)),
              const SizedBox(height: 16),
              Expanded(
                child: ListView(
                  children: [
                    _gradeCard('Advanced Statistics', 77.3, 'B+', AppColors.primary),
                    _gradeCard('Linear Algebra', 82.1, 'A-', AppColors.teal),
                    _gradeCard('Calculus', 71.5, 'B', AppColors.green),
                    _gradeCard('Physics', 68.9, 'B-', AppColors.accent),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _gradeCard(String course, double score, String letter, Color color) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: AppColors.bgCard,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.border),
      ),
      child: Row(
        children: [
          Container(
            width: 52,
            height: 52,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                  colors: [color, color.withOpacity(0.6)]),
              borderRadius: BorderRadius.circular(14),
            ),
            child: Center(
              child: Text(letter,
                  style: GoogleFonts.spaceGrotesk(
                      fontSize: 18,
                      fontWeight: FontWeight.w800,
                      color: Colors.white)),
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(course,
                    style: GoogleFonts.inter(
                        fontSize: 15,
                        fontWeight: FontWeight.w600,
                        color: AppColors.textPrimary)),
                const SizedBox(height: 6),
                LinearProgressIndicator(
                  value: score / 100,
                  backgroundColor: AppColors.border,
                  valueColor: AlwaysStoppedAnimation(color),
                  borderRadius: BorderRadius.circular(4),
                ),
              ],
            ),
          ),
          const SizedBox(width: 14),
          Text(score.toString(),
              style: GoogleFonts.spaceGrotesk(
                  fontSize: 20,
                  fontWeight: FontWeight.w800,
                  color: color)),
        ],
      ),
    );
  }
}

// ───────────────────────────────────────────────
// Student Profile Tab
// ───────────────────────────────────────────────
class StudentProfileTab extends StatelessWidget {
  const StudentProfileTab({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(gradient: AppGradients.background),
      child: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(
            children: [
              const SizedBox(height: 20),
              CircleAvatar(
                radius: 50,
                backgroundColor: AppColors.teal.withOpacity(0.2),
                child: Text('S',
                    style: GoogleFonts.spaceGrotesk(
                        fontSize: 40,
                        fontWeight: FontWeight.w800,
                        color: AppColors.teal)),
              ),
              const SizedBox(height: 14),
              Text('Student',
                  style: GoogleFonts.spaceGrotesk(
                      fontSize: 22,
                      fontWeight: FontWeight.w700,
                      color: AppColors.textPrimary)),
              Text('Computer Science - Year 2',
                  style: GoogleFonts.inter(
                      fontSize: 13, color: AppColors.textSecondary)),
              const SizedBox(height: 28),
              _infoCard([
                (Icons.email_rounded, 'Email', 'student@university.edu'),
                (Icons.badge_rounded, 'Student ID', 'CS-2024-0042'),
                (Icons.calendar_today_rounded, 'Enrolled', 'September 2023'),
              ]),
              const SizedBox(height: 16),
              _infoCard([
                (Icons.bar_chart_rounded, 'Current GPA', '3.4 / 4.0'),
                (Icons.military_tech_rounded, 'Standing', 'Dean\'s List'),
                (Icons.school_rounded, 'Credits', '64 / 132'),
              ]),
            ],
          ),
        ),
      ),
    );
  }

  Widget _infoCard(List<(IconData, String, String)> items) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.bgCard,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        children: items.map((item) {
          return Padding(
            padding: const EdgeInsets.symmetric(vertical: 10),
            child: Row(
              children: [
                Icon(item.$1, color: AppColors.teal, size: 20),
                const SizedBox(width: 12),
                Text(item.$2,
                    style: GoogleFonts.inter(
                        fontSize: 14, color: AppColors.textSecondary)),
                const Spacer(),
                Text(item.$3,
                    style: GoogleFonts.inter(
                        fontSize: 14,
                        fontWeight: FontWeight.w600,
                        color: AppColors.textPrimary)),
              ],
            ),
          );
        }).toList(),
      ),
    );
  }
}
