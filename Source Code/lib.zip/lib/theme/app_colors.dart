import 'package:flutter/material.dart';

class AppColors {
  static const Color bgDark = Color(0xFF0A0E1A);
  static const Color bgCard = Color(0xFF111827);
  static const Color bgCardLight = Color(0xFF1C2537);
  static const Color primary = Color(0xFF6C63FF);
  static const Color primaryGrad = Color(0xFF00C6C6);
  static const Color accent = Color(0xFFF59E0B);
  static const Color green = Color(0xFF10B981);
  static const Color red = Color(0xFFEF4444);
  static const Color teal = Color(0xFF06B6D4);
  static const Color purple = Color(0xFF8B5CF6);
  static const Color textPrimary = Color(0xFFFFFFFF);
  static const Color textSecondary = Color(0xFF9CA3AF);
  static const Color border = Color(0xFF1F2D3D);
  static const Color inputBg = Color(0xFF1A2540);
}

class AppGradients {
  static const LinearGradient primaryBtn = LinearGradient(
    colors: [Color(0xFF6C63FF), Color(0xFF00C6C6)],
    begin: Alignment.centerLeft,
    end: Alignment.centerRight,
  );

  static const LinearGradient background = LinearGradient(
    colors: [Color(0xFF0A0E1A), Color(0xFF0D1B2E), Color(0xFF0A0E1A)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static const LinearGradient parentPortal = LinearGradient(
    colors: [Color(0xFFFF6B35), Color(0xFFFF8C42)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static const LinearGradient statBlue = LinearGradient(
    colors: [Color(0xFF0EA5E9), Color(0xFF06B6D4)],
  );
  static const LinearGradient statGreen = LinearGradient(
    colors: [Color(0xFF10B981), Color(0xFF059669)],
  );
  static const LinearGradient statRed = LinearGradient(
    colors: [Color(0xFFEF4444), Color(0xFFDC2626)],
  );
  static const LinearGradient statPurple = LinearGradient(
    colors: [Color(0xFF8B5CF6), Color(0xFF7C3AED)],
  );
}
